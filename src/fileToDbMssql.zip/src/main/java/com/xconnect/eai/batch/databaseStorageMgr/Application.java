package com.xconnect.eai.batch.databaseStorageMgr;

import org.apache.commons.io.FileUtils;

/**
 * <pre>
 * com.xconnect.eai 
 *    |_ databaseStorageMgr.Application.java
 * 
 * </pre>
 * @date : 2020. 1. 6. 오후 2:07:18
 * @version : 
 * @author : A931461
 */
public class Application {

	public static void main(String[] args) {
//			MariadbConnect mariadbConnect = new MariadbConnect();
		
			try {
				// 0) 3일치로 파일 정리작업 (move 처리)
				// 1) DB connection 에러가 아니면 fail 폴더로 이동
				String path	=	PropertiesUtil.get("config", "ftp.file.log.dir");
				HRProcessManager filewatcher	=	new HRProcessManager(path);
				filewatcher.start();
				System.out.println("HRProcessManager watch start~~~~~~~~~~~~~~~~~");
			}
			catch (Exception se) {			
					System.out.println("databaseStorageMgr - Table TB_ADM_DATA_DEL_MGNT Data Query Fail !");
		    	    se.printStackTrace();
		   } finally {
		   }
		
	}

}
