package com.xconnect.eai.batch.db;

import org.apache.commons.dbcp2.BasicDataSource;

import com.xconnect.eai.batch.databaseStorageMgr.PropertiesUtil;

/**
 * @author ashraf
 *
 */
public class DataSource {

	private static final String DRIVER_CLASS_NAME = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static  String DB_URL = "";
	public static  String DB_USER = "";
	public static  String DB_PASSWORD = "";
	private static final int CONN_POOL_SIZE = 5;

	private BasicDataSource bds = new BasicDataSource();

	public DataSource() {
		String ipaddr	=	PropertiesUtil.get("config", "db.svr.ip");
		String port		=	PropertiesUtil.get("config", "db.svr.port");
		String dbname	=	PropertiesUtil.get("config", "db.svr.dbname");
		DB_URL			=	String.format("jdbc:sqlserver://%s:%s;databaseName="+dbname+";",ipaddr,port);
		DB_USER			=	PropertiesUtil.get("config", "db.userId");
		DB_PASSWORD		=	PropertiesUtil.get("config", "db.userPass");
		
		
		//Set database driver name
		bds.setDriverClassName(DRIVER_CLASS_NAME);
		//Set database url
		bds.setUrl(DB_URL);
		//Set database user
		bds.setUsername(DB_USER);
		//Set database password
		bds.setPassword(DB_PASSWORD);
		//Set the connection pool size
		bds.setInitialSize(CONN_POOL_SIZE);
	}

	private static class DataSourceHolder {
		private static final DataSource INSTANCE = new DataSource();
	}

	public static DataSource getInstance() {
		return DataSourceHolder.INSTANCE;
	}

	public BasicDataSource getBds() {
		return bds;
	}

	public void setBds(BasicDataSource bds) {
		this.bds = bds;
	}
}
