/*
 * Copyright Hyundai-AutoEver
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of HAE. ("Confidential Information").
 */

package com.xconnect.eai.batch.databaseStorageMgr; 

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xconnect.eai.batch.db.DataSource;
import com.xconnect.eai.batch.process.BatchProcess;
//import com.xconnect.eai.server.common.exception.XConnectEaiServerException;
//import com.xconnect.eai.server.common.util.CommonReflectionUtils;
//import com.xconnect.eai.external.CommonInvoker;
import com.xconnect.eai.server.common.util.CommonUtils;

/**
 * <pre>
 * com.xconnect.eai.server.service.register
 *    |_ HotdeployLibManager.java
 * 
 * </pre>
 * @date : 2020. 3. 26. 오전 9:20:02
 * @version : 
 * @author : A931744
 */
/**
 * <pre>
 * com.xconnect.eai.batch.databaseStorageMgr 
 *    |_ HRProcessManager.java
 * 
 * </pre>
 * @date : 2021. 1. 2. 오전 1:38:40
 * @version : 
 * @author : 6801740
 */
public class HRProcessManager {

	private static final Logger LOG = LoggerFactory.getLogger(HRProcessManager.class);

	private String hrFilePath = "";
	private WatchKey watchKey;
	private WatchService watchService = null;
	private Thread watcher = null;
	private static final Map<String, URLClassLoader> libLoaderMap = new HashMap<String, URLClassLoader>();
	BatchProcess dataTransfer = new BatchProcess();
	FTPDataToJDBC	dataJDBC	=	new FTPDataToJDBC(); 

	
	//@SuppressWarnings("unused")
	public HRProcessManager() {}
	
	public HRProcessManager(String watch_folder) throws Exception {
		hrFilePath	=	watch_folder;
		dataJDBC.setDataSource(DataSource.getInstance().getBds());
	}
	

	/**
	 * <pre>
	 * 1. 개요 : 
	 * 2. 처리내용 : 
	 * </pre>
	 * @Method Name : start
	 * @date : 2021. 1. 2.
	 * @author : 6801740
	 * @history : 
	 * <pre>
	 *	-----------------------------------------------------------------------
	 *	변경일	         작성자                변경내용  
	 *	----------- ------------------- ---------------------------------------
	 *	2021. 1. 2.		6801740				최초 작성 
	 *	-----------------------------------------------------------------------
	 * <pre>
	 *
	 * @throws IOException
	 */ 	
	public void start() throws IOException {
		try {
			// watchService 생성
			WatchService watchService = FileSystems.getDefault().newWatchService();
			// 경로 생성
			Path path = Paths.get(hrFilePath);
			// 해당 디렉토리 경로에 WatchService와 Event 등록 (file 생성, 삭제, 수정, overflow 이벤트 등록)
			path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE, 
					StandardWatchEventKinds.ENTRY_DELETE, 
					StandardWatchEventKinds.ENTRY_MODIFY, 
					StandardWatchEventKinds.OVERFLOW);
			
			
			dataJDBC.initDirectory(hrFilePath);
			

			Thread thread = new Thread(() -> {
				while (true) {
					try {
						watchKey = watchService.take();						// 이벤트가 오길 대기(Blocking)
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					List<WatchEvent<?>> events = watchKey.pollEvents();		// 이벤트들을 가져옴
					for (WatchEvent<?> event : events) {
						// 이벤트 종류
						Kind<?> kind = event.kind();
						// 경로
						Path paths = (Path) event.context();

						String fileName = hrFilePath + File.separator + paths.toString();
						
						// file .tab
						if(!fileName.trim().toLowerCase().endsWith(".tab")) continue;

						//System.out.println(paths.toAbsolutePath());
						if (kind.equals(StandardWatchEventKinds.ENTRY_CREATE)) {			// Directory entry created.
							LOG.debug("+-[ watchService ]------:: ENTRY_CREATE >> " + fileName);
							dataJDBC.fileCheckTail(hrFilePath+ File.separator,paths.toString());
						} else if (kind.equals(StandardWatchEventKinds.ENTRY_DELETE)) {		// Directory entry deleted.
							LOG.debug("+-[ watchService ]------:: ENTRY_DELETE >> " + fileName);
						} else if (kind.equals(StandardWatchEventKinds.ENTRY_MODIFY)) {		// Directory entry modified.
							LOG.debug("+-[ watchService ]------:: ENTRY_MODIFY >> " + fileName);
							dataJDBC.fileCheckTail(hrFilePath+ File.separator,paths.toString());
						} else if (kind.equals(StandardWatchEventKinds.OVERFLOW)) {			// A special event to indicate that events may have been lost or discarded.
						} else {
							System.out.println("## Watch Folder :: Unknown Event. >> " + fileName);
						}
					}
					if (!watchKey.reset()) {
						try {
							watchService.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
			thread.start();

		} catch (IOException e) {
			LOG.error("[HotdeployProcessManager] >> start > Error! :: {}", CommonUtils.getPrintStackTrace(e));
		}		
	}

	/**
	 * Watch Service stop및 thread 정리
	 */
	public void stop() {
		try {
			if(watchService != null) {
				watchService.close();
			}
			if(watcher != null) {
				watcher.join();
			}
		} catch (Exception e) {
			LOG.error("[HotdeployProcessManager] >> stop > Error! :: {}", CommonUtils.getPrintStackTrace(e));
		}
	}
}
