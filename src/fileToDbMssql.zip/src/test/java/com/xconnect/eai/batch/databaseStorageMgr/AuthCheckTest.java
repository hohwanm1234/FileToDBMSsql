/*
 * Copyright Hyundai AutoEver.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of Hyundai AutoEver. ("Confidential Information").
 */
package com.xconnect.eai.batch.databaseStorageMgr; 

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * com.xconnect.eai.test.auth 
 *    |_ AuthCheckTest.java
 * 
 * </pre>
 * @date : 2020. 2. 11. 오후 5:10:44
 * @version : 
 * @author : A931744
 */
public class AuthCheckTest {

	private static final Logger LOG = LoggerFactory.getLogger(AuthCheckTest.class);

	@Test
	public void request_header_check_test() throws Exception {
		  String id = "corn";
		LOG.trace("trace, id : {}", id);
        LOG.debug("debug, id : {}", id);
        LOG.info("info, id : {}", id);
        LOG.warn("warn, id : {}", id);
        LOG.error("error, id : {}", id);
        
        System.out.println(getDayAgoDate(-3));
        System.out.println(getDayFromFileName("2.TAB"));
        System.out.println(isBetween("2.TAB"));
        System.out.println(isBetween("20201225000.TAB"));        
        System.out.println(isBetween("20201230000.TAB"));        
        
        String thisDay = new java.text.SimpleDateFormat ("yyyyMMdd").format(new java.util.Date());

        String gates = "6-1-５(S/P-３)－ＩＮ,6-1-５(S/P-３)－ＯＵＴ,4-1-1-지원인원사무실（５";
        
        if(gates.contains("6-1-５(S/P-３)－ＯＵＴ")) System.out.println("exits");
        if(gates.contains("6-1-５(S/P-３)－ＯＵＴ2")) System.out.println("exits");
        
        
        
        
        
	}

	private boolean isBetween(String fileName) {
		try {
			String dateStr		=	getDayFromFileName(fileName);
			String dateBefore3	=	getDayAgoDate(-3);
			if(Integer.parseInt(dateStr) >= Integer.parseInt(dateBefore3)) {
				return true;
			}
		}catch(Exception ex) {
			ex.printStackTrace(System.out);
		}
		return false;
	}	


	private String getDayFromFileName(String fileName) {
		if(fileName.length() >= 8) {
			return fileName.substring(0,8);
		}else {
			return "19000101";
		}
	}	

	private String getDayAgoDate(int period) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, period);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		return formatter.format(cal.getTime());
	}



	

}
