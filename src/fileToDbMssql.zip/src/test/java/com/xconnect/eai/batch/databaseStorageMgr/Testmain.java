package com.xconnect.eai.batch.databaseStorageMgr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
 
public class Testmain {
     public static void main(String[] args) {
         //패키지 경로를 포함한 클래스명 또는 .class를 통해  Logger를 얻는다.
         Logger logger = LoggerFactory.getLogger("dololak.LoggerTest");
//       Logger logger = LoggerFactory.getLogger(LoggerTest.class);
         logger.debug("Hello world.");
         logger.error("Hello world.");
     }
}
